# -*- coding: utf-8 -*-
"""
Created on Sat Jul 11 13:56:18 2020

@author: nikola blagojevic e-mail: blagojevic@ibk.baug.ethz.ch
"""

import System
import Component
import RSGroup
import numpy as np
import DamageFunctionalityRelation
import unittest
import Priorities
import math

# test the virtual community from iReCoDeS paper (2020)
class TestSystem(unittest.TestCase):
    
    def setUp(self):
        pass
    

if __name__ == '__main__':
    unittest.main()       
    